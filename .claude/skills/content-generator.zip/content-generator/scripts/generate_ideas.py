#!/usr/bin/env python3
"""
Content Idea Generator for Safe Driving Token Platform
Generates social media content ideas by synthesizing multiple data sources
with business pillars, platform specs, and target segments.

This implementation uses LLM-based synthesis for intelligent content generation.
"""

import json
import random
import sys
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional


class ContentGenerator:
    def __init__(self, base_path: Path = None, config_path: Path = None, use_llm: bool = True):
        """Initialize the content generator with configuration files."""
        if config_path is None:
            # Config files are in ../config/ relative to this script
            config_path = Path(__file__).resolve().parent.parent / 'config'

        if base_path is None:
            # For input/output, go up to Content directory
            base_path = Path(__file__).resolve().parent.parent.parent.parent.parent

        self.base_path = base_path
        self.config_path = config_path
        self.script_dir = Path(__file__).resolve().parent
        self.use_llm = use_llm
        self.pillars = self._load_config('pillars.json')
        self.platforms = self._load_config('platforms.json')
        self.segments = self._load_config('segments.json')
        self.input_dir = base_path / 'input'
        self.output_dir = base_path / 'output' / 'generated_ideas'

    def _load_config(self, filename: str) -> Dict:
        """Load a JSON configuration file from the config directory."""
        file_path = self.config_path / filename
        if not file_path.exists():
            raise FileNotFoundError(f"Required configuration file not found: {filename} in {self.config_path}")

        with open(file_path, 'r') as f:
            return json.load(f)

    def _get_parsed_ideas(self, category: str) -> List[Dict]:
        """Get all parsed idea JSON files from a category's parsed directory."""
        parsed_dir = self.input_dir / category / 'parsed'
        if not parsed_dir.exists():
            return []

        ideas = []
        for idea_file in sorted(parsed_dir.glob('idea_*.json')):
            try:
                with open(idea_file, 'r') as f:
                    idea_data = json.load(f)
                    idea_data['_file_path'] = idea_file
                    ideas.append(idea_data)
            except Exception as e:
                print(f"Warning: Error reading {idea_file}: {e}")

        return ideas

    def _is_idea_used(self, idea_file: Path) -> bool:
        """Check if an idea has been marked as used."""
        idea_id = idea_file.stem  # e.g., "idea_001"
        marker_path = idea_file.parent / f".{idea_id}.used"
        return marker_path.exists()

    def _mark_idea_used(self, idea_file: Path, generated_file: str):
        """Mark an idea as used by creating a marker file."""
        idea_id = idea_file.stem
        marker_path = idea_file.parent / f".{idea_id}.used"

        marker_data = {
            "used_date": datetime.now().strftime('%Y-%m-%d'),
            "used_timestamp": datetime.now().isoformat(),
            "generated_file": generated_file,
            "idea_id": idea_id
        }

        with open(marker_path, 'w') as f:
            json.dump(marker_data, f, indent=2)

    def select_ideas(self, mode: str = 'random', count: int = 1,
                    specific_id: Optional[str] = None,
                    category: Optional[str] = None) -> List[Dict]:
        """
        Select ideas based on the specified mode.

        Args:
            mode: Selection mode ('random', 'sequential', 'specific', 'batch')
            count: Number of ideas to select (for random and batch modes)
            specific_id: Specific idea ID to use (for specific mode)
            category: Category to select from (default: all categories)

        Returns:
            List of selected idea dictionaries
        """
        # Gather all parsed ideas
        all_ideas = []
        categories = [category] if category else ['human_insights', 'seasonal', 'external_feeds']

        for cat in categories:
            ideas = self._get_parsed_ideas(cat)
            all_ideas.extend(ideas)

        if not all_ideas:
            print("❌ No parsed ideas found. Please run the idea-parser skill first.")
            return []

        # Filter out used ideas (unless specific mode is used)
        if mode != 'specific':
            unused_ideas = [idea for idea in all_ideas
                           if not self._is_idea_used(idea['_file_path'])]

            if not unused_ideas:
                print("⚠️ All ideas have been used!")
                print("Options:")
                print("  1. Add new input ideas and run idea-parser")
                print("  2. Delete .idea_*.used markers to reset usage tracking")
                print("  3. Use specific mode to reuse an idea")
                return []

            available_ideas = unused_ideas
        else:
            available_ideas = all_ideas

        # Select based on mode
        selected = []

        if mode == 'random':
            selected = [random.choice(available_ideas)] if available_ideas else []

        elif mode == 'sequential':
            # Sort by idea ID and pick the first unused one
            sorted_ideas = sorted(available_ideas, key=lambda x: x.get('id', ''))
            selected = [sorted_ideas[0]] if sorted_ideas else []

        elif mode == 'specific':
            if not specific_id:
                print("❌ Specific mode requires an idea ID")
                return []

            # Find the specific idea
            for idea in all_ideas:
                if idea.get('id') == specific_id:
                    selected = [idea]
                    break

            if not selected:
                print(f"❌ Idea {specific_id} not found")
                return []

        elif mode == 'batch':
            # Select multiple random ideas
            if count > len(available_ideas):
                print(f"⚠️ Requested {count} ideas but only {len(available_ideas)} unused ideas available")
                count = len(available_ideas)

            selected = random.sample(available_ideas, count)

        else:
            print(f"❌ Unknown selection mode: {mode}")
            return []

        return selected

    def _call_claude_llm(self, prompt: str) -> Optional[str]:
        """Call Claude CLI to synthesize content using true LLM."""
        try:
            # Prepare input JSON for bash wrapper
            input_data = {'prompt': prompt}
            input_json = json.dumps(input_data)

            # Call the bash wrapper script
            wrapper_script = self.script_dir / 'synthesize_with_llm.sh'
            result = subprocess.run(
                ['bash', str(wrapper_script)],
                input=input_json,
                capture_output=True,
                text=True,
                timeout=60
            )

            if result.returncode != 0:
                print(f"⚠️ Claude CLI error: {result.stderr}")
                return None

            return result.stdout.strip()

        except subprocess.TimeoutExpired:
            print("⚠️ Claude CLI call timed out after 60 seconds")
            return None
        except Exception as e:
            print(f"⚠️ Error calling Claude CLI: {e}")
            return None

    def synthesize_with_llm(self, parsed_idea: Dict) -> Dict:
        """
        Synthesize content using LLM-based approach.

        If use_llm is True, calls Claude CLI for true LLM synthesis.
        Otherwise, falls back to intelligent keyword-based synthesis.
        """
        # Extract data from parsed idea
        title = parsed_idea.get('title', 'Untitled')
        raw_text = parsed_idea.get('raw_text', '')
        key_points = parsed_idea.get('key_points', [])
        metadata = parsed_idea.get('metadata', {})

        # Build LLM prompt
        llm_prompt = f"""You are a social media content strategist for Zenlit, a safe driving token rewards platform targeting gig economy drivers.

Given this content idea parsed from Reddit:

Title: {title}
Content: {raw_text}
Key Points: {', '.join(key_points)}
Source Metadata: {json.dumps(metadata, indent=2)}

Available content pillars:
{json.dumps(self.pillars, indent=2)}

Platform requirements:
{json.dumps(self.platforms, indent=2)}

Target segment:
{json.dumps(self.segments, indent=2)}

Task: Synthesize this into a social media content idea by:

1. Select the most appropriate pillar from the pillars list based on the idea's theme
2. Create a compelling core message that connects this idea to our safe driving token rewards platform
3. Generate two content variants:
   - Generic version: Suitable for all audiences (under 100 chars)
   - Gig driver version: Specifically addressing gig economy drivers' pain points (under 100 chars)
4. Adapt the content for ALL 6 platforms with platform-appropriate tone:
   - linkedin: Professional, data-driven (100-300 chars)
   - instagram: Visual-first with engaging caption
   - tiktok: Ultra-short, catchy (20-60 chars)
   - twitter: Timely, concise (100-280 chars)
   - facebook: Community-focused (40-80 chars)
   - reddit: Discussion-starter, value-first
5. Score the idea (1-10) based on: relevance to our mission, timeliness, engagement potential, actionability

Output ONLY a valid JSON object with this exact structure:
{{
  "pillar_id": "string (id from pillars list)",
  "pillar_rationale": "string (why this pillar was selected)",
  "core_message": "string (the main message)",
  "variants": {{
    "generic": "string (generic version)",
    "gig_driver": "string (driver-specific version)"
  }},
  "platform_adaptations": {{
    "linkedin": "string",
    "instagram": "string",
    "tiktok": "string",
    "twitter": "string",
    "facebook": "string",
    "reddit": "string"
  }},
  "score": number (1-10),
  "score_rationale": "string (why this score)"
}}

Return ONLY the JSON object, no other text."""

        # Try to use Claude LLM if enabled
        llm_result = None
        if self.use_llm:
            print(f"  🤖 Calling Claude LLM for synthesis...")
            llm_response = self._call_claude_llm(llm_prompt)

            if llm_response:
                try:
                    # Try to parse the JSON response
                    # Claude might wrap the JSON in markdown code blocks, so clean it
                    cleaned_response = llm_response.strip()
                    if cleaned_response.startswith('```'):
                        # Extract JSON from code block
                        lines = cleaned_response.split('\n')
                        cleaned_response = '\n'.join(lines[1:-1])

                    llm_result = json.loads(cleaned_response)
                    print(f"  ✅ LLM synthesis successful")
                except json.JSONDecodeError as e:
                    print(f"  ⚠️ Failed to parse LLM response as JSON: {e}")
                    print(f"  ⚠️ Response preview: {llm_response[:200]}...")
                    llm_result = None

        # If LLM succeeded, format and return the result
        if llm_result:
            pillar_id = llm_result.get('pillar_id')
            pillar = next((p for p in self.pillars['pillars'] if p['id'] == pillar_id),
                         self.pillars['pillars'][0])

            return {
                'id': parsed_idea.get('id', 'unknown'),
                'pillar': pillar['id'],
                'pillar_rationale': llm_result.get('pillar_rationale', ''),
                'core_message': llm_result.get('core_message', ''),
                'source_idea': {
                    'title': title,
                    'key_points': key_points,
                    'href': parsed_idea.get('href', ''),
                    'source_metadata': metadata
                },
                'variants': llm_result.get('variants', {}),
                'platform_adaptations': llm_result.get('platform_adaptations', {}),
                'score': llm_result.get('score', 5.0),
                'score_rationale': llm_result.get('score_rationale', ''),
                'synthesis_method': 'claude_llm'
            }

        # FALLBACK: Use intelligent keyword-based synthesis
        print(f"  🔄 Using fallback synthesis method")

        # Select most relevant pillar based on keywords
        pillar = self._select_relevant_pillar(title, raw_text, key_points)

        # Generate intelligent core message
        core_message = self._generate_core_message(title, key_points, pillar)

        # Create variants
        variants = {
            'generic': self._create_intelligent_generic(core_message, title),
            'gig_driver': self._create_intelligent_segment(core_message, title, key_points)
        }

        # Adapt for ALL platforms
        platform_adaptations = {}
        for platform in self.platforms['platforms']:
            platform_id = platform['id']
            platform_adaptations[platform_id] = self._adapt_intelligently(
                variants['generic'], platform, core_message
            )

        # Score the idea
        score = self._score_idea(parsed_idea, pillar)

        return {
            'id': parsed_idea.get('id', 'unknown'),
            'pillar': pillar['id'],
            'pillar_rationale': f"Selected {pillar['name']} based on content relevance",
            'core_message': core_message,
            'source_idea': {
                'title': title,
                'key_points': key_points,
                'href': parsed_idea.get('href', ''),
                'source_metadata': metadata
            },
            'variants': variants,
            'platform_adaptations': platform_adaptations,
            'score': score,
            'score_rationale': self._get_score_rationale(score),
            'synthesis_method': 'keyword_fallback'
        }

    def _select_relevant_pillar(self, title: str, text: str, key_points: List[str]) -> Dict:
        """Intelligently select the most relevant pillar based on content."""
        # Combine all text for analysis
        combined = f"{title} {text} {' '.join(key_points)}".lower()

        # Keyword mapping for pillars
        pillar_keywords = {
            'safety_education': ['safety', 'accident', 'risk', 'protect', 'secure', 'caution'],
            'token_community': ['earn', 'reward', 'token', 'income', 'money', 'save', 'cost'],
            'advocacy_impact': ['policy', 'law', 'regulation', 'rights', 'advocacy', 'change'],
            'product_tips': ['tip', 'feature', 'how to', 'guide', 'app', 'maximize'],
            'seasonal_trending': ['holiday', 'season', 'winter', 'summer', 'trending', 'event'],
            'entertainment_humor': ['funny', 'humor', 'story', 'laugh', 'joke', 'entertaining']
        }

        # Score each pillar
        scores = {}
        for pillar in self.pillars['pillars']:
            pillar_id = pillar['id']
            keywords = pillar_keywords.get(pillar_id, [])
            score = sum(1 for kw in keywords if kw in combined)
            scores[pillar_id] = score

        # Get pillar with highest score, or random if all zero
        if max(scores.values()) > 0:
            best_pillar_id = max(scores, key=scores.get)
            return next(p for p in self.pillars['pillars'] if p['id'] == best_pillar_id)
        else:
            return random.choice(self.pillars['pillars'])

    def _generate_core_message(self, title: str, key_points: List[str], pillar: Dict) -> str:
        """Generate an intelligent core message."""
        # Extract key insight
        insight = key_points[0] if key_points else title

        # Connect to pillar theme
        pillar_name = pillar['name'].lower()

        # Create message that ties insight to safe driving platform
        if 'safety' in pillar_name:
            return f"{insight} - Drive safer, earn more with our token rewards"
        elif 'token' in pillar_name or 'community' in pillar_name:
            return f"{insight} - Turn safe driving into earnings"
        elif 'advocacy' in pillar_name:
            return f"{insight} - Join the movement for safer roads"
        elif 'product' in pillar_name or 'tips' in pillar_name:
            return f"{insight} - Maximize your rewards with this tip"
        elif 'seasonal' in pillar_name or 'trending' in pillar_name:
            return f"{insight} - Stay safe this season, earn tokens"
        else:
            return f"{insight} - Safe driving pays off"

    def _create_intelligent_generic(self, core_message: str, title: str) -> str:
        """Create an intelligent generic version."""
        # Keep it punchy and under 100 chars
        short_core = core_message.split(' - ')[0] if ' - ' in core_message else core_message
        return f"{short_core[:80]}... Learn more!"

    def _create_intelligent_segment(self, core_message: str, title: str, key_points: List[str]) -> str:
        """Create an intelligent segment-specific version."""
        # Focus on gig driver pain points
        short_core = core_message.split(' - ')[0] if ' - ' in core_message else core_message

        # Add driver-specific call-to-action
        if any(word in core_message.lower() for word in ['earn', 'money', 'save', 'cost']):
            return f"Gig drivers: {short_core[:60]} = More $$"
        elif any(word in core_message.lower() for word in ['safety', 'safe', 'protect']):
            return f"Night shift safety: {short_core[:60]}"
        else:
            return f"For drivers: {short_core[:70]}"

    def _adapt_intelligently(self, content: str, platform: Dict, core_message: str) -> str:
        """Intelligently adapt content for each platform."""
        platform_id = platform['id']
        char_limit = platform.get('optimal_text_length', {})

        # Platform-specific tone and format
        if platform_id == 'linkedin':
            # Professional, data-driven (100-300 chars)
            return f"New insights: {core_message[:250]}"

        elif platform_id == 'instagram':
            # Visual-first, lifestyle
            return f"📸 {content} [Swipe for more]"

        elif platform_id == 'tiktok':
            # Ultra-short, catchy (20-60 chars)
            words = content.split()[:5]
            return ' '.join(words)

        elif platform_id == 'twitter':
            # Timely, concise (100-280 chars)
            return content[:250]

        elif platform_id == 'facebook':
            # Community-focused (40-80 chars)
            return content[:70]

        elif platform_id == 'reddit':
            # Discussion-starter, value-first
            return f"Discussion: {core_message}"

        else:
            return content

    def _score_idea(self, parsed_idea: Dict, pillar: Dict) -> float:
        """Score the idea based on multiple factors."""
        score = 5.0  # Base score

        # Relevance: Check if idea has engagement data
        metadata = parsed_idea.get('metadata', {})
        if 'engagement' in metadata:
            score += 1.5

        # Timeliness: Check if recently extracted
        extracted_date = parsed_idea.get('extracted_date', '')
        if extracted_date:
            try:
                extracted = datetime.strptime(extracted_date, '%Y-%m-%d')
                days_old = (datetime.now() - extracted).days
                if days_old < 7:
                    score += 2.0
                elif days_old < 30:
                    score += 1.0
            except:
                pass

        # Content quality: Check for key points
        key_points = parsed_idea.get('key_points', [])
        score += min(len(key_points) * 0.5, 1.5)

        return min(score, 10.0)  # Cap at 10

    def _get_score_rationale(self, score: float) -> str:
        """Generate rationale for the score."""
        if score >= 8:
            return "Highly relevant, timely, and engaging content with strong potential"
        elif score >= 6:
            return "Good content with solid engagement potential"
        elif score >= 4:
            return "Moderate potential, may need optimization"
        else:
            return "Lower priority, consider enhancing or holding"

    def generate_ideas(self, mode: str = 'random', count: int = 1,
                      specific_id: Optional[str] = None,
                      category: Optional[str] = None) -> Dict:
        """
        Generate content ideas using parsed ideas and LLM synthesis.

        Args:
            mode: Selection mode ('random', 'sequential', 'specific', 'batch')
            count: Number of ideas to generate
            specific_id: Specific idea ID (for specific mode)
            category: Category to select from (optional)
        """
        # Select ideas based on mode
        selected_ideas = self.select_ideas(mode, count, specific_id, category)

        if not selected_ideas:
            return {
                'generated_date': datetime.now().strftime('%Y-%m-%d'),
                'generated_timestamp': datetime.now().isoformat(),
                'total_ideas': 0,
                'ideas': [],
                'error': 'No ideas selected'
            }

        # Synthesize each selected idea using LLM approach
        synthesized_ideas = []
        for parsed_idea in selected_ideas:
            synthesized = self.synthesize_with_llm(parsed_idea)
            synthesized_ideas.append(synthesized)

        return {
            'generated_date': datetime.now().strftime('%Y-%m-%d'),
            'generated_timestamp': datetime.now().isoformat(),
            'total_ideas': len(synthesized_ideas),
            'selection_mode': mode,
            'ideas': synthesized_ideas
        }

    def save_output(self, ideas: Dict) -> Optional[str]:
        """
        Save generated ideas to properly named JSON file in output/generated_ideas/.

        Returns:
            Path to saved file, or None if no ideas to save
        """
        if ideas.get('total_ideas', 0) == 0:
            print("⚠️ No ideas generated - output file not created")
            return None

        # Create output directory if it doesn't exist
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # Generate filename with timestamp
        timestamp = datetime.now().strftime('%Y-%m-%d_%H%M')
        filename = f"content_idea_{timestamp}.json"
        output_path = self.output_dir / filename

        # Check for conflicts and add suffix if needed
        counter = 1
        while output_path.exists():
            filename = f"content_idea_{timestamp}_{counter}.json"
            output_path = self.output_dir / filename
            counter += 1

        # Save to file
        with open(output_path, 'w') as f:
            json.dump(ideas, f, indent=2)

        print(f"✅ Content ideas generated successfully!")
        print(f"📝 Output saved to: {output_path}")
        print(f"📊 Total ideas generated: {ideas['total_ideas']}")

        # Mark all used ideas
        for idea in ideas['ideas']:
            source_id = idea.get('id')
            if source_id:
                # Find the original file path
                for category in ['human_insights', 'seasonal', 'external_feeds']:
                    idea_file = self.input_dir / category / 'parsed' / f"{source_id}.json"
                    if idea_file.exists():
                        self._mark_idea_used(idea_file, filename)
                        print(f"  ✓ Marked {source_id} as used")
                        break

        return str(output_path)


def main():
    """Main execution function with CLI argument support."""
    import argparse

    parser = argparse.ArgumentParser(description='Generate social media content ideas')
    parser.add_argument('--mode', choices=['random', 'sequential', 'specific', 'batch'],
                       default='random', help='Idea selection mode')
    parser.add_argument('--count', type=int, default=1,
                       help='Number of ideas to generate')
    parser.add_argument('--id', type=str, help='Specific idea ID (for specific mode)')
    parser.add_argument('--category', choices=['human_insights', 'seasonal', 'external_feeds'],
                       help='Limit selection to specific category')
    parser.add_argument('--use-llm', dest='use_llm', action='store_true', default=True,
                       help='Use Claude LLM for content synthesis (default: True)')
    parser.add_argument('--no-llm', dest='use_llm', action='store_false',
                       help='Disable LLM synthesis, use keyword-based fallback')

    args = parser.parse_args()

    try:
        generator = ContentGenerator(use_llm=args.use_llm)

        # Generate ideas
        ideas = generator.generate_ideas(
            mode=args.mode,
            count=args.count,
            specific_id=args.id,
            category=args.category
        )

        # Save output
        output_file = generator.save_output(ideas)

        if output_file and ideas.get('total_ideas', 0) > 0:
            # Print summary
            print("\n" + "="*60)
            print("📊 GENERATION SUMMARY")
            print("="*60)
            print(f"Mode: {args.mode}")
            print(f"Total ideas: {ideas['total_ideas']}")

            # Count by pillar
            pillar_counts = {}
            for idea in ideas['ideas']:
                pillar = idea['pillar']
                pillar_counts[pillar] = pillar_counts.get(pillar, 0) + 1

            print("\n🎯 Ideas by Pillar:")
            for pillar, count in pillar_counts.items():
                print(f"  • {pillar}: {count}")

            # Average score
            avg_score = sum(idea['score'] for idea in ideas['ideas']) / len(ideas['ideas'])
            print(f"\n⭐ Average score: {avg_score:.1f}/10")

            print("="*60)

    except FileNotFoundError as e:
        print(f"❌ Configuration Error: {e}")
        print("Ensure pillars.json, platforms.json, and segments.json exist in config/")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
